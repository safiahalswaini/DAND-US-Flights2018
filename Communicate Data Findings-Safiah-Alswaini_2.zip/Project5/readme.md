# Diamonds Data Exploration

## Dataset
The data consisted of 6,044,346 flights Recordes and Cancelled flights equals 81545 . The attributes included Airlines, Cancellation Reasons (Weather, Carrier, NAS, Security), Delay Reason, Delay Minutes, 
Dataset Avaliable [here](https://www.kaggle.com/yuanyuwendymu/airline-delay-and-cancellation-data-2009-2018)


## Summary of Findings

In the exploration, I found that Cancelled Flights in the dataset represent 1.3% of 2018 Flights,the highst cancelled airline is 
Southwest Airlines Co with 18,275 flight, and the least Airline's cancelled flights are Hawaiian Airlines Inc with 250, then Virgin America.

Weather Issues are the highest Cancellation and Delay issues especially in January and March,

January and March have highest Cancelled Flights in 2018 and least Cancelled flights occurred on October and April and it seems to Decrease at the end of the year compared with First months

There was strong corellation between Arraival Delay and Departure, It's Linear relationship, Frontier Airlines Inc is the worste airline for departures and Arrival, then JetBlue Airways
and Alaska Airlines Inc was the best for arrivals. 



## Key Insights for Presentation

For the presentation, I focus on just the Cancelled Flights and It's Disrtibution on Airline using Bar chart, Reasons of Canellation and thier occurance per month using line Plot,also After Notice that the haighest reason is Weather I check It out Delay Average Timme of Delay types.
